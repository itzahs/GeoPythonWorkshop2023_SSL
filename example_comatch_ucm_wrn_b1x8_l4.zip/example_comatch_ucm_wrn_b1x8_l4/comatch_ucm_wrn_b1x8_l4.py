train = dict(
    eval_step=1024,
    total_steps=524288,
    trainer=dict(
        type='CoMatch',
        threshold=0.95, #pseudolabel threshold
        queue_batch=5,  #memory buffer
        contrast_threshold=0.8, #similarity matrix
        da_len=32, #distribution alignment
        T=0.2, # temperature
        alpha=0.9,# 1-alpha for memory smoothed pseudo label
        lambda_u=1.0, #unlabeled loss
        lambda_c=1.0, #contrastive loss
        loss_x=dict(type='cross_entropy', reduction='mean')))

num_classes = 21

model = dict(
    type='wideresnet', #config for resnet purposes
     depth=28,
     widen_factor=2, #reducing number of filters for memory
     dropout=0,
     #type="resnet50", #config for resnet purposes
     #width=1,
     #in_channel=3,
    num_classes=21,
    proj=True,
    low_dim=64)

# Obtained from Imagenet
ucm_mean = [0.485, 0.456, 0.406] 
ucm_std = [0.229, 0.224, 0.225] 

data = dict(
    # Dataset configuration
    type="MyDataset", #customized dataset
    num_workers=4,
    num_labeled=84, #num_labeled/num_classes=labeled samples per class
    num_classes=21,
    batch_size=8, #reducing batch for memory
    expand_labels=False,
    mu=7, #labeled to unlabeled data ratio

    # input data folder
root = "./Classification-SemiCLS/data/UCM/Images",  
labeled_names_file = "./Classification-SemiCLS/data/UCM/Images/UCM_train.txt",  
test_names_file = "./Classification-SemiCLS/data/UCM/Images/UCM_test.txt", 

# labeled data preprocessing
lpipelines = [
    [
        dict(type="RandomHorizontalFlip", p=0.5),
        dict(type="RandomResizedCrop", size=224, scale=(0.2, 1.0)),
        dict(type="ToTensor"),
        dict(type="Normalize", mean=ucm_mean, std=ucm_std)
    ]
],

# unlabeled data preprocessing
upipelinse = [
    # weak augmentation
    [
        dict(type="RandomHorizontalFlip"),
        dict(type="Resize", size=256),
        dict(type="CenterCrop", size=224),
        dict(type="ToTensor"),
        dict(type="Normalize", mean=ucm_mean, std=ucm_std)
    ],

    # strong augmentation 1
    [
        dict(type="RandomHorizontalFlip"),
        dict(type="RandomResizedCrop", size=224, scale=(0.2, 1.0)),
        dict(type="RandAugmentMC", n=2, m=10),
        dict(type="ToTensor"),
        dict(type="Normalize", mean=ucm_mean, std=ucm_std)
    ],

    # strong augmentation 2
    [
        dict(type="RandomResizedCrop", size=224, scale=(0.2, 1.0)),
        dict(type="RandomHorizontalFlip"),
        dict(
            type="RandomApply",
            transforms=[
                dict(
                    type="ColorJitter",
                    brightness=0.4,
                    contrast=0.4,
                    saturation=0.4,
                    hue=0.1
                ),
            ],
            p=0.8
        ),
        dict(type="RandomGrayscale", p=0.2),
        dict(type="ToTensor")
    ]
],

# validation data preprocessing
vpipeline = [
    dict(type="Resize", size=256),
    dict(type="CenterCrop", size=224),
    dict(type="ToTensor"),
    dict(type="Normalize", mean=ucm_mean, std=ucm_std)
])

scheduler = dict(
    type="cosine_schedule_with_warmup",
    num_warmup_steps=0,
    num_training_steps=train["total_steps"]
)

ema = dict(use=True, pseudo_with_ema=False, decay=0.999) # True if using EMA during pseudolabelling

# apex AMP optimization level selected in ['O0', 'O1', 'O2', and 'O3'].
# See details at https://nvidia.github.io/apex/amp.html
amp = dict(use=False, opt_level="O1")

log = dict(interval=1)
ckpt = dict(interval=1)

# optimizer
optimizer = dict(type="SGD", lr=0.03, momentum=0.9, weight_decay=0.0005, nesterov=True)


    